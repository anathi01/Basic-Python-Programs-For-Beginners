factorial_of_entered_integer = 1

entered_integer = int(input())
m_entered_integer = entered_integer
m_entered_integer += 1

while m_entered_integer > 1:
    m_entered_integer -= 1
    factorial_of_entered_integer = factorial_of_entered_integer * m_entered_integer
    
print("The Factorial of", entered_integer, "is :", factorial_of_entered_integer)