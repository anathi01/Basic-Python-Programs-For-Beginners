list_in_celsius = [x for x in range(30, 46)]
list_in_fahrenheit = [x for x in range(30, 46)]

for i in range (len(list_in_fahrenheit)):
    list_in_fahrenheit[i] = (list_in_fahrenheit[i] * 9/5) + 32



print("Celsius", "\t Fahrenheit")

for i in range (len(list_in_celsius)):
    print(list_in_celsius[i], "\t \t", list_in_fahrenheit[i])