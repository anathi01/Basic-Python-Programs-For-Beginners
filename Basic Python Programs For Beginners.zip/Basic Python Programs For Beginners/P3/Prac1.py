## YOUR CODE COMES HERE
mark_entered = 5
list_of_marks = []

def checkmark_validity(mark):
    return 0 < mark <= 100
    
while checkmark_validity(mark_entered):
    mark_entered = float(input())
    if (checkmark_validity(mark_entered)):
        list_of_marks.append(mark_entered)


print(sum(list_of_marks))
print(round(sum(list_of_marks) / len(list_of_marks)))
#Last line in the program