mass_of_object = float(input("Enter the object's mass: "))
velocity_of_object = float(input("\nEnter the object's velocity: "))

momentum_of_object = mass_of_object * velocity_of_object
kineticEnergy_of_object = (1/2) * (mass_of_object * (velocity_of_object ** 2))

print("\nThe object's momentum is", momentum_of_object)
print("\nThe object's kinetic energy is", kineticEnergy_of_object)