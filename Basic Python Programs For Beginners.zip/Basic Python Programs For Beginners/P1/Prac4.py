distance_in_kilometers = float(input("Enter the number of kilometers: "))

distance_in_nauticalmiles = distance_in_kilometers / (10000 / (90 * 60))
print("The number of nautical miles is", distance_in_nauticalmiles)