mass_of_object = float(input("Enter the object's mass: "))
velocity_of_object = float(input("Enter the object's velocity: "))

momentum_of_object = mass_of_object * velocity_of_object

print("The object's momentum is", momentum_of_object)