number_of_years = int(input("Enter the number of years: "))

distance_travelled = (3 * (10 ** 8))*(number_of_years * (60 ** 2) * (24) * (365))

print("Light travels", distance_travelled, "meters in", number_of_years, "years.")