def float_function(float_num):#DO NOT MODIFY HERE. THIS IS THE FUNCTION HEADER
    #YOUR CODE TO ANSWER THE QUESTION COME HERE
    if (float_num > 0):
        if (abs(float_num) < 1):
            return "positive small"
        elif (abs(float_num) > 1 * 10**6):
            return "positive large"
        else:
            return "positive"
    elif (float_num < 0):
        if (abs(float_num) < 1):
            return "negative small"
        elif (abs(float_num) > 1 * 10**6):
            return "negative large"
        else:
            return "negative"
    else:
        return "zero"

 #DO NOT MODIFY HERE. THIS IS THE CODE THAT WILL CALL YOUR FUNCTION
print(float_function(float(input())))