def validatemetric(metric):
    i = 0
    boolean_check = 2
    boolean_iterator = 0
    
    while i != len(metric):
        if (metric[i] >= 0):
            boolean_check = 1
        else:
            boolean_check = 0
        i = i + 1
        
        if (boolean_check == 1):
            boolean_iterator += 1
        
    if (boolean_iterator == i):
        return 1
    elif (boolean_iterator != i):
        return 0
    return 

def bmi(weight, height):
    bmi, interpr= "#Invalid","Invalid#"
    #YOUR CODE IN BETWEEN HERE...
    metrics_to_check = [weight, height]
    
    if (validatemetric(metrics_to_check)):
        bmi = (1.3 * weight) / height ** 2.5
        
        if (bmi > 30):
            interpr="Obese"
        elif (bmi >= 25):
            interpr="Overweight"
        elif (bmi >= 18.5):
            interpr="Normal"
        elif (bmi >= 0):
            interpr="Underweight"
        
    #AND HERE....
    
    return bmi, interpr
        
        
        

#Do not touch this code. It is my code to test your function        
print(bmi(int(input()), float(input()))) 