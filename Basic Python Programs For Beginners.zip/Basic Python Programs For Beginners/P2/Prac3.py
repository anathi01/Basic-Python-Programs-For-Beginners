def increase_decrease(num1, num2, num3):
    boolean_check = 2
    
    if (num2 > num3):
        if (num1 > num2):
           boolean_check = 0
           return "decreasing"
        else:
            if (boolean_check == 2):
                return "neither"
    elif (num3 > num2):
        if (num2 > num1):
           boolean_check = 1
           return "increasing"
        else:
            if (boolean_check == 2):
                return "neither"
    else:
        if (boolean_check == 2):
            return "neither"
    
print(increase_decrease(int(input()), int(input()), int(input())))