def checkmark(mark):
    i = 0
    boolean_check = 2
    boolean_iterator = 0
    
    while i != len(mark):
        if (mark[i] < 0 or mark[i] > 100):
            boolean_check = 0
        else:
            boolean_check = 1
        i = i + 1
        
        if (boolean_check == 1):
            boolean_iterator += 1
        
    if (boolean_iterator == i):
        return 1
    elif (boolean_iterator != i):
        return 0
    
    # Hope there isnt marks for optimization XD 
            

def dp(test1, test2, test3, prac, quizz):
    grade="Invalid"
    dp_grade ="###Error###"
    
    #Put your code between these comments
    marks_to_check = [test1, test2, test3, prac, quizz]
    
    if (checkmark(marks_to_check)):
        dp_grade = ((test1 + test2 + test3) / 3) * 0.625 + ((prac + quizz) / 2) * 0.375
    
        if (dp_grade > 100):
            grade="Invalid"
        elif (dp_grade >= 75):
            grade="Distinction"
        elif (dp_grade >= 65):
            grade="Credit"
        elif (dp_grade >= 50):
            grade="Pass"
        elif (dp_grade >= 0):
            grade="Fail"
    #Up to here
    
        
    return dp_grade, grade               
        

#Do not touch this code. It is my code to test your function        
print(dp(int(input()), int(input()), int(input()),int(input()), int(input())))