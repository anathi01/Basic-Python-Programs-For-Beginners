def compare(num1 , num2 , num3):
    if (num1 == num2 and num3 == num2):
        return "All the same"
    elif (num1 == num2 and num3 != num2):
        return "num1 is equal to num2"
    elif (num1 == num3 and num3 != num2):
        return "num1 is equal to num3"
    elif (num1 != num2 and num3 == num2):
        return "num2 is equal to num3"
    elif (num1 != num2 and num3 != num2):
        return "All different"
        
print(compare(int(input()), int(input()), int(input())))