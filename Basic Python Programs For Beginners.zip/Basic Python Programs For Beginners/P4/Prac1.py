project_sales = float(input("Please enter the projected amount of total sales : "))

profit  = project_sales * 0.23
print("The profit to be made from", f"{project_sales:.2f}", "is", f"{round(profit, 2):.2f}")