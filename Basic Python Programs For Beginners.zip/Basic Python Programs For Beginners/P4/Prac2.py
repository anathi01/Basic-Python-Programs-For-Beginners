print("The distance the car will travel in", 6, "hours", "is:", 70 * 6, "km")
print("The distance the car will travel in", 10, "hours", "is:", 70 * 10, "km")
print("The distance the car will travel in", 15, "hours", "is:", 70 * 15, "km")