a = eval(input())
b = eval(input())

c = ((a ** 2) + (b ** 2))

print(int(c ** 0.5))