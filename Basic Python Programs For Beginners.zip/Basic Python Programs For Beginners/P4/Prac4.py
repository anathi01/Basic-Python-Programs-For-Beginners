a = eval(input("Enter num1 "))
b = eval(input("\nEnter num2 "))

print("The sum of", a, "and", b, "is", a+b)
print("\nThe difference between", a, "and", b, "is", abs(a-b))
print("\nThe product of", a, "and", b, "is", a*b)

if ((a+b)/2 - int((a+b)/2) == 0):
    print("\nIs the sum of", a, "and", b, "odd?", "False")
else:
    print("\nIs the sum of", a, "and", b, "odd?", "True")
