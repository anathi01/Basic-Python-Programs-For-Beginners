a = int(input("Input the first number: "))
b = int(input("Input the second number: "))

if (a > 0 and b > 0):
    if ((a/b) > 1):
        print(a, "is larger")
    elif ((a/b) < 1):
        print(b, "is larger")
    elif ((a/b) == 1):
        print("These numbers are equal")
elif (a < 0 and b < 0):
    if ((a/b) < 1):
        print(a, "is larger")
    elif ((a/b) > 1):
        print(b, "is larger")
    elif ((a/b) == 1):
        print("These numbers are equal")
